chrome.runtime.sendMessage({
  method: 'rc-emulate-press'
});
